import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Calendar, Clock, CreditCard } from 'lucide-react'

interface CTASectionProps {
  negocioSlug: string
}

export function CTASection({ negocioSlug }: CTASectionProps) {
  return (
    <section className="py-20 bg-gradient-to-br from-primary to-primary/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-8">
          {/* Headline */}
          <div className="space-y-4">
            <h2 className="text-3xl lg:text-4xl font-bold text-white">
              ¿Listo para agendar tu turno?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Reserva online en menos de 2 minutos. Sin llamadas, sin esperas.
            </p>
          </div>

          {/* Beneficios */}
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center gap-3 text-white">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-lg">Agenda 24/7</h3>
              <p className="text-white/80 text-sm">
                Reserva cuando quieras, desde donde estés
              </p>
            </div>

            <div className="flex flex-col items-center gap-3 text-white">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                <Clock className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-lg">Confirmación Inmediata</h3>
              <p className="text-white/80 text-sm">
                Recibe confirmación al instante por WhatsApp
              </p>
            </div>

            <div className="flex flex-col items-center gap-3 text-white">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                <CreditCard className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-lg">Pago Seguro</h3>
              <p className="text-white/80 text-sm">
                Paga online de forma rápida y segura
              </p>
            </div>
          </div>

          {/* CTA Button */}
          <div className="pt-4">
            <Button 
              asChild 
              size="lg" 
              variant="secondary"
              className="text-lg px-12 py-6 shadow-xl hover:shadow-2xl transition-shadow"
            >
              <Link href={`/${negocioSlug}/reservar`}>
                Reservar Mi Turno Ahora
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}