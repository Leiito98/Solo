import { MapPin, Phone, Mail, Clock } from 'lucide-react'

interface FooterProps {
  negocio: {
    nombre: string
    direccion?: string | null
    telefono?: string | null
    email?: string | null
  }
}

export function Footer({ negocio }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Columna 1: Info del negocio */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold">{negocio.nombre}</h3>
            <p className="text-gray-400">
              Reserva tu turno online de forma rápida y sencilla
            </p>
          </div>

          {/* Columna 2: Contacto */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contacto</h3>
            <div className="space-y-3">
              {negocio.direccion && (
                <div className="flex items-start gap-3 text-gray-400">
                  <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{negocio.direccion}</span>
                </div>
              )}
              {negocio.telefono && (
                <a 
                  href={`tel:${negocio.telefono}`}
                  className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors"
                >
                  <Phone className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm">{negocio.telefono}</span>
                </a>
              )}
              {negocio.email && (
                <a 
                  href={`mailto:${negocio.email}`}
                  className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors"
                >
                  <Mail className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm">{negocio.email}</span>
                </a>
              )}
            </div>
          </div>

          {/* Columna 3: Horarios (placeholder) */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Horarios</h3>
            <div className="space-y-2 text-sm text-gray-400">
              <div className="flex justify-between">
                <span>Lun - Vie:</span>
                <span>9:00 - 20:00</span>
              </div>
              <div className="flex justify-between">
                <span>Sábado:</span>
                <span>9:00 - 18:00</span>
              </div>
              <div className="flex justify-between">
                <span>Domingo:</span>
                <span>Cerrado</span>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-sm text-gray-400">
          <p>© {new Date().getFullYear()} {negocio.nombre}. Todos los derechos reservados.</p>
          <p className="mt-2">
            Powered by <span className="text-primary font-semibold">Solo</span>
          </p>
        </div>
      </div>
    </footer>
  )
}