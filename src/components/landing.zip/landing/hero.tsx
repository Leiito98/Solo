import { Button } from '@/components/ui/button'
import { MapPin, Clock, Phone } from 'lucide-react'
import Link from 'next/link'

interface HeroProps {
  negocio: {
    nombre: string
    vertical: string
    direccion?: string | null
    telefono?: string | null
    slug: string
  }
}

const VERTICAL_TEXTS: Record<string, { title: string, description: string }> = {
  barberia: {
    title: 'Tu estilo, nuestra pasión',
    description: 'Reserva tu turno online y disfruta de un servicio profesional'
  },
  belleza: {
    title: 'Belleza que transforma',
    description: 'Agenda tu cita y descubre tu mejor versión'
  },
  nutricion: {
    title: 'Tu salud, nuestra prioridad',
    description: 'Agenda tu consulta nutricional personalizada'
  },
  psicologia: {
    title: 'Cuidamos tu bienestar emocional',
    description: 'Reserva tu sesión de terapia online'
  },
  fitness: {
    title: 'Alcanza tus objetivos',
    description: 'Entrena con profesionales certificados'
  },
  otros: {
    title: 'Servicios profesionales',
    description: 'Agenda tu cita de forma rápida y sencilla'
  }
}

export function Hero({ negocio }: HeroProps) {
  const verticalText = VERTICAL_TEXTS[negocio.vertical] || VERTICAL_TEXTS.otros

  return (
    <section className="relative bg-gradient-to-br from-blue-50 to-indigo-100 py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 leading-tight">
                {negocio.nombre}
              </h1>
              <p className="text-xl lg:text-2xl text-gray-600">
                {verticalText.title}
              </p>
              <p className="text-lg text-gray-500">
                {verticalText.description}
              </p>
            </div>

            {/* Info Cards */}
            <div className="flex flex-wrap gap-4">
              {negocio.direccion && (
                <div className="flex items-center gap-2 bg-white px-4 py-3 rounded-lg shadow-sm">
                  <MapPin className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium text-gray-700">
                    {negocio.direccion}
                  </span>
                </div>
              )}
              {negocio.telefono && (
                <a 
                  href={`tel:${negocio.telefono}`}
                  className="flex items-center gap-2 bg-white px-4 py-3 rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <Phone className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium text-gray-700">
                    {negocio.telefono}
                  </span>
                </a>
              )}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="text-lg px-8 py-6">
                <Link href={`/${negocio.slug}/reservar`}>
                  Reservar Turno Ahora
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6">
                <a href="#servicios">
                  Ver Servicios
                </a>
              </Button>
            </div>
          </div>

          {/* Right Image/Placeholder */}
          <div className="relative">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
              {/* Placeholder - después se puede reemplazar con imagen real */}
              <div className="text-center space-y-4">
                <div className="w-32 h-32 mx-auto rounded-full bg-white shadow-lg flex items-center justify-center">
                  <span className="text-6xl">
                    {negocio.vertical === 'barberia' && '💈'}
                    {negocio.vertical === 'belleza' && '💅'}
                    {negocio.vertical === 'nutricion' && '🥗'}
                    {negocio.vertical === 'psicologia' && '🧠'}
                    {negocio.vertical === 'fitness' && '💪'}
                    {negocio.vertical === 'otros' && '✨'}
                  </span>
                </div>
                <p className="text-gray-500 font-medium">
                  Imagen destacada próximamente
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}