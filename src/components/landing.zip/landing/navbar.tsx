'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Phone, MapPin } from 'lucide-react'

interface NavbarProps {
  negocio: {
    nombre: string
    logo_url?: string | null
    telefono?: string | null
    slug: string
  }
}

export function LandingNavbar({ negocio }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo / Nombre */}
          <div className="flex items-center gap-3">
            {negocio.logo_url ? (
              <img 
                src={negocio.logo_url} 
                alt={negocio.nombre}
                className="h-10 w-10 rounded-lg object-cover"
              />
            ) : (
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-lg">
                  {negocio.nombre[0].toUpperCase()}
                </span>
              </div>
            )}
            <span className="text-xl font-bold text-gray-900">
              {negocio.nombre}
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <a 
              href="#servicios" 
              className="text-gray-600 hover:text-gray-900 font-medium transition-colors"
            >
              Servicios
            </a>
            <a 
              href="#profesionales" 
              className="text-gray-600 hover:text-gray-900 font-medium transition-colors"
            >
              Profesionales
            </a>
            {negocio.telefono && (
              <a 
                href={`tel:${negocio.telefono}`}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span className="text-sm">{negocio.telefono}</span>
              </a>
            )}
            <Button asChild size="lg">
              <Link href={`/${negocio.slug}/reservar`}>
                Reservar Turno
              </Link>
            </Button>
          </div>

          {/* Mobile CTA */}
          <div className="md:hidden">
            <Button asChild>
              <Link href={`/${negocio.slug}/reservar`}>
                Reservar
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}