import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Card, CardContent } from '@/components/ui/card'

interface Profesional {
  id: string
  nombre: string
  especialidad?: string | null
  foto_url?: string | null
  bio?: string | null
}

interface ProfesionalesProps {
  profesionales: Profesional[]
}

export function ProfesionalesSection({ profesionales }: ProfesionalesProps) {
  if (!profesionales || profesionales.length === 0) {
    return null
  }

  return (
    <section id="profesionales" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Nuestro Equipo
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Profesionales capacitados y apasionados por lo que hacen
          </p>
        </div>

        {/* Grid de Profesionales */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {profesionales.map((profesional) => {
            const initials = profesional.nombre
              .split(' ')
              .map(n => n[0])
              .join('')
              .toUpperCase()
              .slice(0, 2)

            return (
              <Card 
                key={profesional.id}
                className="border-gray-200 hover:border-primary hover:shadow-lg transition-all duration-200"
              >
                <CardContent className="p-6 text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-gray-100">
                    <AvatarImage src={profesional.foto_url || undefined} />
                    <AvatarFallback className="bg-primary text-white text-xl font-bold">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  
                  <h3 className="text-lg font-bold text-gray-900 mb-1">
                    {profesional.nombre}
                  </h3>
                  
                  {profesional.especialidad && (
                    <p className="text-sm text-primary font-medium mb-3">
                      {profesional.especialidad}
                    </p>
                  )}
                  
                  {profesional.bio && (
                    <p className="text-sm text-gray-600 line-clamp-3">
                      {profesional.bio}
                    </p>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}