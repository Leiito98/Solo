import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Clock, DollarSign } from 'lucide-react'
import Link from 'next/link'

interface Servicio {
  id: string
  nombre: string
  descripcion?: string | null
  duracion_min: number
  precio: number
}

interface ServiciosProps {
  servicios: Servicio[]
  negocioSlug: string
}

export function ServiciosSection({ servicios, negocioSlug }: ServiciosProps) {
  if (!servicios || servicios.length === 0) {
    return null
  }

  return (
    <section id="servicios" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Elige el servicio que necesitas y agenda tu turno en minutos
          </p>
        </div>

        {/* Grid de Servicios */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicios.map((servicio) => (
            <Card 
              key={servicio.id} 
              className="border-gray-200 hover:border-primary hover:shadow-lg transition-all duration-200 group"
            >
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Nombre del servicio */}
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-primary transition-colors">
                    {servicio.nombre}
                  </h3>

                  {/* Descripción */}
                  {servicio.descripcion && (
                    <p className="text-gray-600 text-sm line-clamp-2">
                      {servicio.descripcion}
                    </p>
                  )}

                  {/* Info: Duración y Precio */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Clock className="w-4 h-4" />
                      <span className="text-sm font-medium">
                        {servicio.duracion_min} min
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-primary">
                      <DollarSign className="w-5 h-5" />
                      <span className="text-xl font-bold">
                        {Number(servicio.precio).toLocaleString('es-AR')}
                      </span>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <Button asChild className="w-full mt-4" variant="outline">
                    <Link href={`/${negocioSlug}/reservar?servicio=${servicio.id}`}>
                      Reservar
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}